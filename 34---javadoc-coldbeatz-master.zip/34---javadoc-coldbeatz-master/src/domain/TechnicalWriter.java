package domain;

/**
 * Клас {@code TechnicalWriter} представляє об'єкт технічного писателя.
 * 
 * @see  Artist
 * @see  Manager
 * @see  GraphicIllustrator
 * @see  Employee
 * @see  Editor
 */
public class TechnicalWriter extends Artist {
	
}
